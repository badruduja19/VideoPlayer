 
//  Created by SK Badruduja on 11/28/19.
//  Copyright © 2019 SK Badruduja. All rights reserved.
//

import UIKit

class PlayerCell: UICollectionViewCell {
    var data:DataObj? {
        didSet {
         //   self.imgView.image = data?.image
            self.labTitle.text = data?.title
        }
    }
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var labTitle: UILabel!
    override func prepareForReuse() {
        super.prepareForReuse()
        self.imgView.isHidden = false
        data = nil
    }
}
