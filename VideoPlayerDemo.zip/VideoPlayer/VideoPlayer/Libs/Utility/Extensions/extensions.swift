 //
 //  Created by SK Badruduja on 11/28/19.
 //  Copyright © 2019 SK Badruduja. All rights reserved.
//

import UIKit


// uicolor init simplified
extension UIColor{
    class func rbg(r: CGFloat, g: CGFloat, b: CGFloat) -> UIColor {
        let color = UIColor.init(red: r/255, green: g/255, blue: b/255, alpha: 1)
        return color
    }
}

// UIImage with downloadable content
extension UIImage {
  class  func contentOfURL(link: String) -> UIImage {
    let url = URL.init(string: link)!
    var image = UIImage()
    do{
        let data = try Data.init(contentsOf: url)
        image = UIImage.init(data: data)!
    } catch _ {
        print("error downloading images")
    }
    return image
    }
}


enum stateOfVC {
    case minimized
    case fullScreen
    case hidden
}
enum Direction {
    case up
    case left
    case none
}


extension UIView
{
    /// This method return the parent UIViewController of a UIView
    ///
    /// - Returns: parent controller of UIView (i.e. self)
    func parentViewController() -> UIViewController? {
        return self.traverseResponderChainForUIViewController() as? UIViewController
    }
    
    private func traverseResponderChainForUIViewController() -> AnyObject? {
        if let nextResponder = self.next {
            if nextResponder is UIViewController {
                return nextResponder
            } else if nextResponder is UIView {
                return (nextResponder as! UIView).traverseResponderChainForUIViewController()
            } else {
                return nil
            }
        }
        return nil
    }
}

class LoaderView: UIImageView {
    override func awakeFromNib() {
        super.awakeFromNib()
        
        let rotationAnimation = CABasicAnimation(keyPath: "transform.rotation.z")
        rotationAnimation.toValue = .pi * 2.0 * 2 * 60.0
        rotationAnimation.duration = 200.0
        rotationAnimation.isCumulative = true
        rotationAnimation.repeatCount = Float.infinity
        self.layer.add(rotationAnimation, forKey: "rotationAnimation")
    }
}

