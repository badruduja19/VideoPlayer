 
//  Created by SK Badruduja on 11/27/19.
//  Copyright © 2019 SK Badruduja. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {

    @IBOutlet weak var cvVideoPlayer: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.cvVideoPlayer.reloadData()
        self.navigationController?.title = "Video List"
    }
    
    
    
   func getThumbnailImageFromVideoUrl(url: URL, completion: @escaping ((_ image: UIImage?)->Void)) {
        DispatchQueue.global().async {
            let asset = AVAsset(url: url)
            let avAssetImageGenerator = AVAssetImageGenerator(asset: asset)
            avAssetImageGenerator.appliesPreferredTrackTransform = true
            let thumnailTime = CMTimeMake(value: 2, timescale: 1)
            do {
                let cgThumbImage = try avAssetImageGenerator.copyCGImage(at: thumnailTime, actualTime: nil)  
                let thumbImage = UIImage(cgImage: cgThumbImage)
                DispatchQueue.main.async {
                    completion(thumbImage)
                }
            } catch {
                print(error.localizedDescription)
                DispatchQueue.main.async {
                    completion(nil)
                }
            }
        }
    }

}

extension ViewController: UICollectionViewDataSource, UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return DemoSource.shared.demoData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PlayerCell", for: indexPath) as? PlayerCell {
            
            let data =  DemoSource.shared.demoData[indexPath.row]
            cell.data = data
            
           
            self.getThumbnailImageFromVideoUrl(url:  data.play_Url! ) { (thumImage) in
                
                cell.imgView.image = thumImage;
            }
             
            
            return cell
        }
        return UICollectionViewCell()
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let data =  DemoSource.shared.demoData[indexPath.row]
        let cell:PlayerCell = collectionView.cellForItem(at:  indexPath) as! PlayerCell
        
        
        let vc:VideoDetailsVC = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "VideoDetailsVC") as! VideoDetailsVC
        
        vc.url = data.play_Url!
        vc.descStr = data.content
        vc.thumbImg = cell.imgView.image ?? UIImage()
        
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

