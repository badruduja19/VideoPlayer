 
//  Created by SK Badruduja on 11/28/19.
//  Copyright © 2019 SK Badruduja. All rights reserved.
//

import UIKit 

class VideoDetailsVC: UIViewController {
    
    @IBOutlet weak var viewThumb: UIView!
    @IBOutlet weak var ivThuimb: UIImageView!
    @IBOutlet weak var btnPlayFirstTime: UIButton!
    
    @IBOutlet weak var lblDesc: UILabel!
    
    var url = URL(string: "https://content.jwplatform.com/manifests/vM7nH0Kl.m3u8")!
    
    var descStr:String  = ""
    var thumbImg:UIImage = UIImage()
    
    @IBOutlet weak var mediaView: UIView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.title = "Video Details"
        self.mediaView.isHidden = true
        self.viewThumb.isHidden = false
        self.btnPlayFirstTime.isHidden = false
        self.ivThuimb.isHidden = false
        
        
        self.lblDesc.text = descStr
        self.ivThuimb.image = thumbImg
        
    }
     
    
    @IBAction func btnSctionPlayFirstTIme(_ sender: Any) {
        
        
        self.mediaView.isHidden = false
        self.viewThumb.isHidden = true
        self.btnPlayFirstTime.isHidden = true
        self.ivThuimb.isHidden = true
        
        if let player = VideoPlayer.initialize(with: self.mediaView.bounds) {
            player.isToShowPlaybackControls = true
            
            self.mediaView.addSubview(player)
            
           
            
            player.loadVideos(with: [url])
            player.isToShowPlaybackControls = true
            player.isMuted = true
            player.playVideo()
        }
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
